package game;
import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

public class MagicShooter extends StaticBody {
    private static final Shape MagicShooterShape = new PolygonShape(-0.73f, 0.85f, -0.76f, -0.23f, -0.38f, -0.84f, 0.38f, -0.84f, 0.96f, -0.13f, 0.66f, 0.82f, -0.72f, 0.86f);
    private static final BodyImage image = new BodyImage("data/MagicShooter.png", 4);
    private static SoundClip MagicShooterSound;
    static int credits;


    //static {
    //   try {
    //  MagicShooterSound = new SoundClip("data/Bonus.wav");
    //  System.out.println("Loading Coin sound");
    //} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
    //  System.out.println(e);
    // }
    //}

    //constructor
    public MagicShooter(World world) {
        super(world, MagicShooterShape);
        addImage(image);
    }
}


