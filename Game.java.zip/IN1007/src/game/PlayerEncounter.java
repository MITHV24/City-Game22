package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;
import city.cs.engine.CollisionEvent;
public class PlayerEncounter implements CollisionListener {
    private final Game game;
    private Player player;
   GameLevel currentLevel;
    //public PlayerEncounter(Player p) {
    public PlayerEncounter(GameLevel  level,Game game){
        currentLevel=level;
        this.game=game;
        // this.player = p;
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Enemy) {
            player.setLives(player.getLives() - 1);
              if(currentLevel.isComplete())
                  System.out.println("transition to next Level");
              game.goToNextLevel();
             // e.getOthetBody().destroy();
        }
    }
}
