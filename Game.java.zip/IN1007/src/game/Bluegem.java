package game;
import city.cs.engine.*;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
public class Bluegem extends Walker {
    private static final Shape BluegemShape = new PolygonShape(-0.01f, 3.19f, -3.19f, -0.07f, 0.03f, -2.93f, 3.22f, 0.06f, 0.04f, 3.19f);
    static int credits;
    // private static SoundClip BluegemSound;

    // {
    //try {
    //BluegemSound = new SoundClip("data/Bonus.wav");
    //System.out.println("Loading Bluegem sound");
    //} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
    // System.out.println(e);
    //}
    // }


    private static final BodyImage image = new BodyImage("data/Bluegem.gif", 1);

    //constructor
    public Bluegem(World world) {
        super(world, BluegemShape);
        addImage(image);
        credits = 0;
        setAlwaysOutline(false);
    }

    public int getCredits() {
        return credits;
    }

    public static void setCredits(int credits) {
        Bluegem.credits = credits;
    }
}
   //@Override
    //public void destroy() {
      //  BluegemSound.play();
        //super.destroy();
    //}
//}
