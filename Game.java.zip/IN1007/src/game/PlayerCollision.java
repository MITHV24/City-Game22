package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class PlayerCollision implements CollisionListener {
    private Player player;

    public PlayerCollision(Player player) {
        this.player = player;
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Coin) {
            player.setCoin(player.getCoin() + 1);
            e.getOtherBody().destroy();
        } else if (e.getOtherBody() instanceof Bluegem) {
            player.setBluegem(player.getBluegem() + 3);
            e.getOtherBody().destroy();
        } else if (e.getOtherBody() instanceof Enemy) {
            player.setLives(player.getLives() - 1);
        } else if (e.getOtherBody() instanceof MagicShooter) {
            player.setMagicShooter(player.getMagicShooter() + 3);
            e.getOtherBody().destroy();
        }
    }
}



