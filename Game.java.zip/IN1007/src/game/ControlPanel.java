package game;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class ControlPanel {
    public JPanel MainPanel;
    private JButton StartButton;
    private JButton LoadButton;
    private JButton SaveButton;
    private JButton QuitButton;
    private Game game;

    public ControlPanel(JPanel mainPanel) {
        MainPanel = mainPanel;

        QuitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Quit Game");
                System.exit(0);
            }
        });
        SaveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Game saved");
                //try// {
                    //GameSaverLoad.save("data/scores.txt"), game.currentLevel;
               // } catch (IOException EE) {
                 //   ee.printStackTrace();
                }
                //System.exit(0);
            //}

        });
        LoadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Game Loaded");


            }
        });

    }
}
