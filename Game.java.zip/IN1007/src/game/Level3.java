package game;

import city.cs.engine.BoxShape;
import city.cs.engine.Shape;
import city.cs.engine.StaticBody;
import org.jbox2d.common.Vec2;
public class Level3 extends GameLevel {

    private final Player player;

    public Level3() {

        getPlayer().setPosition(new Vec2(7, -6));
        getPlayer().addCollisionListener(new BluegemPickup(getPlayer()));
        getPlayer().addCollisionListener(new CoinPickup(getPlayer()));
        getPlayer().addCollisionListener(new PlayerCollision(getPlayer()));

        Enemy enemy = new Enemy(this);
        enemy.setPosition(new Vec2(0, 7));


        //level1 platforms
        Shape shape = new BoxShape(11, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -11.5f));
        //level 1
        Shape platformShape = new BoxShape(3.5f, 0.5f);
        StaticBody platform1 = new StaticBody(this, platformShape);
        //level 2
        platform1.setPosition(new Vec2(-1, -5.5f));
        StaticBody platform2 = new StaticBody(this, platformShape);
        platform2.setPosition(new Vec2(-8, 2f));
        //level3
        StaticBody platform3 = new StaticBody(this, platformShape);
        platform3.setPosition(new Vec2(-10, 11.8f));
        //level1
        StaticBody platform4 = new StaticBody(this, platformShape);
        platform4.setPosition(new Vec2(10, -3f));

        // coin level1 centre

        Coin coin4 = new Coin(this);
        coin4.setPosition(new Vec2(8, -2));

        //bluegem
        Bluegem bluegem1 = new Bluegem(this);
        bluegem1.setPosition(new Vec2(1, -2));
        Bluegem bluegem2 = new Bluegem(this);
        bluegem2.setPosition(new Vec2(12, 3));
        Bluegem bluegem4 = new Bluegem(this);
        bluegem4.setPosition(new Vec2(12, -2));

        //magicShooter
        MagicShooter magicShooter1= new MagicShooter(this);
        magicShooter1.setPosition(new Vec2(2,-3));
        MagicShooter magicShooter2= new MagicShooter(this);
        magicShooter2.setPosition(new Vec2(-2,-2));
        MagicShooter magicShooter3= new MagicShooter(this);
        magicShooter3.setPosition(new Vec2(-9,-12));
        MagicShooter magicShooter4= new MagicShooter(this);
        magicShooter4.setPosition(new Vec2(-4,-7));

        //player and enemy position
        player = new Player(this);
        player.setPosition(new Vec2(5, -7));

        Enemy enemy1 = new Enemy(this);
        enemy.setPosition(new Vec2(2, 7));

    }
    @Override
    public boolean isComplete() {
        //if (getPlayer().getCoin() == 1)

        return true;
        //else
        //return false;
    }


    // public Player getPlayer(){
    //  return Player;
    // }
}

