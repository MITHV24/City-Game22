
package game;

        import java.io.FileReader;
        import java.io.BufferedReader;
        import java.io.IOException;
        import java.util.ArrayList;
        import java.util.concurrent.CopyOnWriteArrayList;

class ScoreRecord{
            String name;
            int score;
            int minutes;
            int seconds;

            public ScoreRecord(String name,int score,int minutes,int seconds){
                this.name=name;
                this.score=score;
                this.minutes=minutes;
                this.seconds=seconds;

            }
        }

public class HighScoreReader {

    private String fileName;
    private ArrayList<ScoreRecord>scores;

    public HighScoreReader(String fileName) {
        this.fileName = fileName;
        scores=new ArrayList<>();

    }

    public void readScores() throws IOException {
        FileReader fr = null;
        BufferedReader reader = null;
        try {
            System.out.println("Reading " + fileName + " ...");
            fr = new FileReader(fileName);
            reader = new BufferedReader(fr);
            String line = reader.readLine();
            while (line != null) {
                // file is assumed to contain one name, score pair per line
                String[] tokens = line.split(",");
                String name = tokens[0];
                int score = Integer.parseInt(tokens[1]);
                String[]timeTokens=tokens[2].split(":");
                int minutes=Integer.parseInt(timeTokens[0]);
                int seconds=Integer.parseInt(timeTokens[1]);

                ScoreRecord scoreRecord=new ScoreRecord(name,score,minutes,seconds);
                scores.add(scoreRecord);


                System.out.println("Name: " + name + ", Score: " + score);
                line = reader.readLine();
            }
            System.out.println("...done.");
        } finally {
            if (reader != null) {
                reader.close();
            }
            if (fr != null) {
                fr.close();
            }
        }
    }

    public static void main(String[] args) throws IOException {
        System.out.println("Player\tScore\tTime");
        HighScoreReader demo = new HighScoreReader(args[0]);
        demo.readScores();
    }
}