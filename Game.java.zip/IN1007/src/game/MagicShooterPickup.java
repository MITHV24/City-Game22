package game;
import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class MagicShooterPickup implements CollisionListener {
    private Player player;

    public MagicShooterPickup(Player p) {
        player = p;

    }

    @Override
    public void collide(CollisionEvent collisionEvent) {
        if (collisionEvent.getOtherBody() instanceof game.MagicShooter) {
            //System.out.println("collided");
            player.setMagicShooter(player.getBluegem()+5);
            collisionEvent.getOtherBody().destroy();
        }
    }
}

