package game;

import city.cs.engine.SoundClip;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import static game.GameView.*;


public class Game {
    GameLevel currentLevel;
    GameView View;

    final JFrame frame = null;

    private SoundClip gameMusic;

    public Game() {
        currentLevel  = new Level1() {
            @Override
            public boolean isComplete() {
                return false;
            }
        };

        //add background music
        try {
            gameMusic = new SoundClip("data/vampire.mp3");
            gameMusic.loop();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println(e);
        }


        GameLevel world = new GameLevel() {
            @Override
            public boolean isComplete() {
                return false;
            }
        };
        Player p = world.getPlayer();
        GameView view = new GameView(world, 800, 600);
        view.addMouseListener(new GiveFocus(view));
        view.addKeyListener(new PlayerController(world.getPlayer()));

        final JFrame frame = new JFrame("City Game");
        frame.add(view);
        JButton  button =new JButton("Start");
        frame.add(button, BorderLayout.EAST);
        button.addActionListener(new ButtonPress());
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.requestFocus();
                currentLevel.start();
            }
        });

        JButton button1 =new JButton("Save");
        frame.add(button1, BorderLayout.PAGE_END);
        button.addActionListener(new ButtonPress());

        JButton button2 =new JButton("Load");
        frame.add(button2, BorderLayout.AFTER_LAST_LINE);
        button.addActionListener(new ButtonPress());

        JButton button3 =new JButton("Quit");
        frame.add(button3, BorderLayout.BEFORE_LINE_BEGINS);
        button.addActionListener(new ButtonPress());

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        frame.setResizable(false);
        frame.pack();
        frame.setVisible(true);
        world.start();

        //start our gane world simulation
        currentLevel.start();
    }

        public void goToNextLevel(){
        currentLevel.stop();
        currentLevel=new Level2( this);
        //GameView.setWorld(currentLevel);
        currentLevel.start();
            System.out.println("transition to next Level");
        }

    public static void main(String[] args) {
        new Game();
    }
}
